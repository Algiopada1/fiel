﻿
namespace Automobili
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblModello = new System.Windows.Forms.Label();
            this.lblMacchina = new System.Windows.Forms.Label();
            this.txtMacchina = new System.Windows.Forms.TextBox();
            this.txtModello = new System.Windows.Forms.TextBox();
            this.lblAlimentazione = new System.Windows.Forms.Label();
            this.cmbAlimentazione = new System.Windows.Forms.ComboBox();
            this.gpxPorte = new System.Windows.Forms.GroupBox();
            this.rdb3 = new System.Windows.Forms.RadioButton();
            this.rdb5 = new System.Windows.Forms.RadioButton();
            this.cbxUsata = new System.Windows.Forms.CheckBox();
            this.btnDati = new System.Windows.Forms.Button();
            this.gpxPorte.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblModello
            // 
            this.lblModello.AutoSize = true;
            this.lblModello.Location = new System.Drawing.Point(12, 50);
            this.lblModello.Name = "lblModello";
            this.lblModello.Size = new System.Drawing.Size(44, 13);
            this.lblModello.TabIndex = 0;
            this.lblModello.Text = "Modello";
            // 
            // lblMacchina
            // 
            this.lblMacchina.AutoSize = true;
            this.lblMacchina.Location = new System.Drawing.Point(12, 9);
            this.lblMacchina.Name = "lblMacchina";
            this.lblMacchina.Size = new System.Drawing.Size(54, 13);
            this.lblMacchina.TabIndex = 1;
            this.lblMacchina.Text = "Macchina";
            // 
            // txtMacchina
            // 
            this.txtMacchina.Location = new System.Drawing.Point(111, 9);
            this.txtMacchina.Name = "txtMacchina";
            this.txtMacchina.Size = new System.Drawing.Size(100, 20);
            this.txtMacchina.TabIndex = 2;
            // 
            // txtModello
            // 
            this.txtModello.Location = new System.Drawing.Point(111, 50);
            this.txtModello.Name = "txtModello";
            this.txtModello.Size = new System.Drawing.Size(100, 20);
            this.txtModello.TabIndex = 3;
            // 
            // lblAlimentazione
            // 
            this.lblAlimentazione.AutoSize = true;
            this.lblAlimentazione.Location = new System.Drawing.Point(12, 206);
            this.lblAlimentazione.Name = "lblAlimentazione";
            this.lblAlimentazione.Size = new System.Drawing.Size(72, 13);
            this.lblAlimentazione.TabIndex = 4;
            this.lblAlimentazione.Text = "Alimentazione";
            // 
            // cmbAlimentazione
            // 
            this.cmbAlimentazione.FormattingEnabled = true;
            this.cmbAlimentazione.Items.AddRange(new object[] {
            "Metano",
            "Ibrido",
            "Benzina",
            "Elettrico"});
            this.cmbAlimentazione.Location = new System.Drawing.Point(134, 206);
            this.cmbAlimentazione.Name = "cmbAlimentazione";
            this.cmbAlimentazione.Size = new System.Drawing.Size(121, 21);
            this.cmbAlimentazione.TabIndex = 5;
            // 
            // gpxPorte
            // 
            this.gpxPorte.Controls.Add(this.rdb5);
            this.gpxPorte.Controls.Add(this.rdb3);
            this.gpxPorte.Location = new System.Drawing.Point(15, 100);
            this.gpxPorte.Name = "gpxPorte";
            this.gpxPorte.Size = new System.Drawing.Size(250, 77);
            this.gpxPorte.TabIndex = 6;
            this.gpxPorte.TabStop = false;
            this.gpxPorte.Text = "Porte";
            // 
            // rdb3
            // 
            this.rdb3.AutoSize = true;
            this.rdb3.Checked = true;
            this.rdb3.Location = new System.Drawing.Point(6, 33);
            this.rdb3.Name = "rdb3";
            this.rdb3.Size = new System.Drawing.Size(31, 17);
            this.rdb3.TabIndex = 0;
            this.rdb3.TabStop = true;
            this.rdb3.Text = "3";
            this.rdb3.UseVisualStyleBackColor = true;
            // 
            // rdb5
            // 
            this.rdb5.AutoSize = true;
            this.rdb5.Location = new System.Drawing.Point(109, 33);
            this.rdb5.Name = "rdb5";
            this.rdb5.Size = new System.Drawing.Size(31, 17);
            this.rdb5.TabIndex = 1;
            this.rdb5.TabStop = true;
            this.rdb5.Text = "5";
            this.rdb5.UseVisualStyleBackColor = true;
            // 
            // cbxUsata
            // 
            this.cbxUsata.AutoSize = true;
            this.cbxUsata.Location = new System.Drawing.Point(15, 268);
            this.cbxUsata.Name = "cbxUsata";
            this.cbxUsata.Size = new System.Drawing.Size(54, 17);
            this.cbxUsata.TabIndex = 7;
            this.cbxUsata.Text = "Usata";
            this.cbxUsata.UseVisualStyleBackColor = true;
            // 
            // btnDati
            // 
            this.btnDati.Location = new System.Drawing.Point(304, 382);
            this.btnDati.Name = "btnDati";
            this.btnDati.Size = new System.Drawing.Size(118, 67);
            this.btnDati.TabIndex = 8;
            this.btnDati.Text = "Visualizza dai";
            this.btnDati.UseVisualStyleBackColor = true;
            this.btnDati.Click += new System.EventHandler(this.btnDati_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.btnDati);
            this.Controls.Add(this.cbxUsata);
            this.Controls.Add(this.gpxPorte);
            this.Controls.Add(this.cmbAlimentazione);
            this.Controls.Add(this.lblAlimentazione);
            this.Controls.Add(this.txtModello);
            this.Controls.Add(this.txtMacchina);
            this.Controls.Add(this.lblMacchina);
            this.Controls.Add(this.lblModello);
            this.MaximumSize = new System.Drawing.Size(450, 500);
            this.MinimumSize = new System.Drawing.Size(450, 500);
            this.Name = "Form1";
            this.Text = "Automobili";
            this.gpxPorte.ResumeLayout(false);
            this.gpxPorte.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblModello;
        private System.Windows.Forms.Label lblMacchina;
        private System.Windows.Forms.TextBox txtMacchina;
        private System.Windows.Forms.TextBox txtModello;
        private System.Windows.Forms.Label lblAlimentazione;
        private System.Windows.Forms.ComboBox cmbAlimentazione;
        private System.Windows.Forms.GroupBox gpxPorte;
        private System.Windows.Forms.RadioButton rdb5;
        private System.Windows.Forms.RadioButton rdb3;
        private System.Windows.Forms.CheckBox cbxUsata;
        private System.Windows.Forms.Button btnDati;
    }
}

