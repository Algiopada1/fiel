﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automobili
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDati_Click(object sender, EventArgs e)
        {
            int ok = 5;
            if (rdb3.Checked == true)
            {
                ok = 3;
            }
            string usata = " ";
            if (cbxUsata.Checked == true)
                usata = usata.Replace(" ", "usata");
            MessageBox.Show("Marca: " + txtMacchina.Text + "\nModello: " + txtModello.Text + "\n" + ok + "porte" + "\nAlimentazione: " + cmbAlimentazione.SelectedItem + "\n" + usata);
        }
    }
}
